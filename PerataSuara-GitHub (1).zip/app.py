"""Perata Suara - ratakan volume suara untuk dubbing video YouTube."""
import os
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageTk

import core

BG = "#0b1020"
PANEL = "#141b33"
FG = "#e8ecff"
ACCENT = "#1fb6ff"
MUTED = "#8b95c9"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Mixing Suara - Perata Volume")
        self.geometry("760x680")
        self.minsize(700, 620)
        self.configure(bg=BG)
        self.files = []          # daftar path
        self.q = queue.Queue()
        self.worker = None
        self.stop_flag = False

        try:
            self.iconbitmap(core.resource_path(os.path.join("assets", "icon.ico")))
        except Exception:
            pass

        self._style()
        self._build()
        self.after(100, self._poll)

    # ---------- tampilan ----------
    def _style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("TFrame", background=BG)
        s.configure("Panel.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=FG, font=("Segoe UI", 10))
        s.configure("Panel.TLabel", background=PANEL, foreground=FG, font=("Segoe UI", 10))
        s.configure("Muted.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 9))
        s.configure("TButton", font=("Segoe UI", 10), padding=6)
        s.configure("Accent.TButton", font=("Segoe UI", 11, "bold"), padding=9,
                    background=ACCENT, foreground="#001018")
        s.map("Accent.TButton", background=[("active", "#5cd0ff"), ("disabled", "#2a3558")])
        s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG,
                    rowheight=26, borderwidth=0, font=("Segoe UI", 10))
        s.configure("Treeview.Heading", background="#1d2748", foreground=FG,
                    font=("Segoe UI", 10, "bold"))
        s.map("Treeview", background=[("selected", "#27406e")])
        s.configure("Horizontal.TProgressbar", troughcolor=PANEL, background=ACCENT)
        s.configure("TCombobox", padding=4)

    def _build(self):
        top = ttk.Frame(self)
        top.pack(fill="x", padx=16, pady=(12, 4))
        try:
            img = Image.open(core.resource_path(os.path.join("assets", "logo.png")))
            img = img.resize((110, 110), Image.LANCZOS)
            self.logo = ImageTk.PhotoImage(img)
            ttk.Label(top, image=self.logo).pack(side="left")
        except Exception:
            pass
        t = ttk.Frame(top)
        t.pack(side="left", padx=14)
        ttk.Label(t, text="Perata Volume Suara", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(t, text="Buat volume dubbing konsisten: tidak keras-pelan, siap untuk YouTube.",
                  style="Muted.TLabel").pack(anchor="w")

        # tombol file
        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=16, pady=(8, 4))
        ttk.Button(bar, text="+ Tambah File", command=self.add_files).pack(side="left")
        ttk.Button(bar, text="+ Tambah Folder", command=self.add_folder).pack(side="left", padx=6)
        ttk.Button(bar, text="Hapus Terpilih", command=self.remove_sel).pack(side="left")
        ttk.Button(bar, text="Bersihkan", command=self.clear).pack(side="left", padx=6)

        # daftar
        box = ttk.Frame(self)
        box.pack(fill="both", expand=True, padx=16, pady=4)
        self.tree = ttk.Treeview(box, columns=("file", "status"), show="headings", selectmode="extended")
        self.tree.heading("file", text="File suara")
        self.tree.heading("status", text="Status")
        self.tree.column("file", width=480)
        self.tree.column("status", width=170, anchor="center")
        sb = ttk.Scrollbar(box, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # pengaturan
        opt = ttk.Frame(self, style="Panel.TFrame")
        opt.pack(fill="x", padx=16, pady=8)
        for c in range(3):
            opt.columnconfigure(c, weight=1)

        def field(col, label, widget):
            f = ttk.Frame(opt, style="Panel.TFrame")
            f.grid(row=0, column=col, padx=10, pady=10, sticky="ew")
            ttk.Label(f, text=label, style="Panel.TLabel").pack(anchor="w")
            widget(f).pack(fill="x", pady=(3, 0))

        self.level = tk.StringVar(value="Sedang (disarankan)")
        field(0, "Kekuatan perataan",
              lambda p: ttk.Combobox(p, textvariable=self.level, values=list(core.LEVELS), state="readonly"))
        self.target = tk.StringVar(value="-16 LUFS (YouTube / dubbing)")
        field(1, "Target volume",
              lambda p: ttk.Combobox(p, textvariable=self.target, state="readonly",
                                     values=["-14 LUFS (lebih keras)", "-16 LUFS (YouTube / dubbing)",
                                             "-18 LUFS (lebih lembut)"]))
        self.fmt = tk.StringVar(value="WAV (kualitas terbaik)")
        field(2, "Format hasil",
              lambda p: ttk.Combobox(p, textvariable=self.fmt, values=list(core.FORMATS), state="readonly"))

        # aksi
        act = ttk.Frame(self)
        act.pack(fill="x", padx=16, pady=(0, 4))
        self.btn = ttk.Button(act, text="MULAI RATAKAN SUARA", style="Accent.TButton", command=self.start)
        self.btn.pack(side="left", fill="x", expand=True)
        ttk.Button(act, text="Buka Folder Hasil", command=self.open_out).pack(side="left", padx=(8, 0))

        self.prog = ttk.Progressbar(self, mode="determinate")
        self.prog.pack(fill="x", padx=16, pady=(6, 2))
        self.info = tk.StringVar(value="Hasil akan disimpan di folder \"Hasil\" di samping aplikasi ini.")
        ttk.Label(self, textvariable=self.info, style="Muted.TLabel").pack(anchor="w", padx=16, pady=(0, 10))

    # ---------- daftar file ----------
    def _add(self, paths):
        for p in paths:
            p = os.path.abspath(p)
            if p not in self.files and p.lower().endswith(core.AUDIO_EXT):
                self.files.append(p)
                self.tree.insert("", "end", iid=p, values=(os.path.basename(p), "Menunggu"))

    def add_files(self):
        ft = [("File audio/video", " ".join("*" + e for e in core.AUDIO_EXT)), ("Semua file", "*.*")]
        self._add(filedialog.askopenfilenames(title="Pilih file suara", filetypes=ft))

    def add_folder(self):
        d = filedialog.askdirectory(title="Pilih folder berisi suara")
        if d:
            self._add(sorted(os.path.join(d, f) for f in os.listdir(d)))

    def remove_sel(self):
        if self.worker and self.worker.is_alive():
            return
        for iid in self.tree.selection():
            self.tree.delete(iid)
            self.files.remove(iid)

    def clear(self):
        if self.worker and self.worker.is_alive():
            return
        self.tree.delete(*self.tree.get_children())
        self.files.clear()
        self.prog["value"] = 0

    def open_out(self):
        try:
            os.startfile(core.output_dir())
        except Exception:
            messagebox.showinfo("Folder Hasil", core.output_dir())

    # ---------- proses ----------
    def start(self):
        if not self.files:
            messagebox.showwarning("Belum ada file", "Tambahkan file suara dulu.")
            return
        if self.worker and self.worker.is_alive():
            return
        target = float(self.target.get().split()[0])
        out = core.output_dir()
        jobs = list(self.files)
        for p in jobs:
            self.tree.set(p, "status", "Menunggu")
        self.prog.configure(maximum=len(jobs), value=0)
        self.btn.state(["disabled"])
        self.worker = threading.Thread(
            target=self._work, args=(jobs, out, target, self.level.get(), self.fmt.get()), daemon=True)
        self.worker.start()

    def _work(self, jobs, out, target, level, fmt):
        ok = 0
        for i, p in enumerate(jobs, 1):
            self.q.put(("status", p, "Memproses..."))
            self.q.put(("info", f"Memproses {i}/{len(jobs)}: {os.path.basename(p)}"))
            try:
                core.process_file(p, out, target, level, fmt)
                self.q.put(("status", p, "Selesai"))
                ok += 1
            except Exception as e:
                self.q.put(("status", p, "Gagal"))
                self.q.put(("error", f"{os.path.basename(p)}: {e}"))
            self.q.put(("prog", i))
        self.q.put(("done", ok, len(jobs), out))

    def _poll(self):
        try:
            while True:
                m = self.q.get_nowait()
                if m[0] == "status":
                    self.tree.set(m[1], "status", m[2])
                elif m[0] == "info":
                    self.info.set(m[1])
                elif m[0] == "prog":
                    self.prog["value"] = m[1]
                elif m[0] == "error":
                    self.info.set(m[1][:140])
                elif m[0] == "done":
                    self.btn.state(["!disabled"])
                    self.info.set(f"Selesai: {m[1]} dari {m[2]} file. Tersimpan di: {m[3]}")
                    messagebox.showinfo("Selesai", f"{m[1]} dari {m[2]} file berhasil diratakan.\n\nLokasi:\n{m[3]}")
        except queue.Empty:
            pass
        self.after(100, self._poll)


if __name__ == "__main__":
    App().mainloop()
