"""Mesin pemrosesan audio untuk Perata Suara (tanpa GUI).

Rantai pemrosesan (memakai FFmpeg):
1. highpass       -> membuang dengung/rumble sangat rendah
2. acompressor    -> menekan bagian yang terlalu keras
3. dynaudnorm     -> menaikkan bagian yang pelan (perataan dinamis)
4. loudnorm 2-pass -> mengunci volume akhir ke target LUFS (standar YouTube)
"""
import json
import os
import re
import subprocess
import sys

AUDIO_EXT = (".wav", ".mp3", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".wma", ".mp4", ".mkv", ".mov")

# Tingkat perataan: (rasio kompresor, threshold dB, gauss dynaudnorm, gain maksimum dynaudnorm)
LEVELS = {
    "Lembut": (2.0, -22, 7, 12),
    "Sedang (disarankan)": (3.0, -24, 7, 30),
    "Kuat": (4.0, -26, 5, 60),
}

FORMATS = {
    "WAV (kualitas terbaik)": (".wav", ["-c:a", "pcm_s16le"]),
    "MP3 320 kbps": (".mp3", ["-c:a", "libmp3lame", "-b:a", "320k"]),
}


def base_dir():
    """Folder tempat aplikasi (exe) berada."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def resource_path(rel):
    root = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(root, rel)


def output_dir():
    d = os.path.join(base_dir(), "Hasil")
    os.makedirs(d, exist_ok=True)
    return d


def ffmpeg_exe():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return "ffmpeg"


def _run(cmd):
    flags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
    return subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="replace", creationflags=flags,
    )


def _pre_filters(level):
    ratio, thr, gauss, gmax = LEVELS[level]
    return (
        "highpass=f=60,"
        f"acompressor=threshold={thr}dB:ratio={ratio}:attack=10:release=250:makeup=2,"
        f"dynaudnorm=f=150:g={gauss}:p=0.92:m={gmax}:s=5"
    )


def unique_path(folder, name, ext):
    path = os.path.join(folder, name + ext)
    n = 2
    while os.path.exists(path):
        path = os.path.join(folder, f"{name} ({n}){ext}")
        n += 1
    return path


def process_file(src, dst_folder, target_lufs=-16.0, level="Sedang (disarankan)",
                 fmt="WAV (kualitas terbaik)", sample_rate=48000):
    """Proses satu file. Mengembalikan path hasil, atau melempar RuntimeError."""
    ff = ffmpeg_exe()
    ext, codec = FORMATS[fmt]
    name = os.path.splitext(os.path.basename(src))[0] + "_rata"
    dst = unique_path(dst_folder, name, ext)
    pre = _pre_filters(level)
    tp = -1.5

    # Pass 1: ukur loudness setelah perataan dinamis
    measure = [ff, "-hide_banner", "-nostdin", "-i", src, "-vn", "-af",
               f"{pre},loudnorm=I={target_lufs}:TP={tp}:LRA=7:print_format=json",
               "-f", "null", "-"]
    r = _run(measure)
    if r.returncode != 0:
        raise RuntimeError("FFmpeg gagal membaca file:\n" + r.stderr[-400:])
    m = re.findall(r"\{[^{}]*\}", r.stderr, re.S)
    stats = None
    if m:
        try:
            stats = json.loads(m[-1])
            float(stats["input_i"])
        except Exception:
            stats = None

    if stats and stats["input_i"] not in ("-inf", "inf"):
        ln = (f"loudnorm=I={target_lufs}:TP={tp}:LRA=7"
              f":measured_I={stats['input_i']}:measured_TP={stats['input_tp']}"
              f":measured_LRA={stats['input_lra']}:measured_thresh={stats['input_thresh']}"
              f":offset={stats['target_offset']}:linear=true")
    else:
        ln = f"loudnorm=I={target_lufs}:TP={tp}:LRA=7"

    # Pass 2: render hasil akhir
    final = [ff, "-hide_banner", "-nostdin", "-y", "-i", src, "-vn", "-af",
             f"{pre},{ln},alimiter=limit=0.89", "-ar", str(sample_rate), "-ac", "2"] + codec + [dst]
    r = _run(final)
    if r.returncode != 0 or not os.path.exists(dst):
        raise RuntimeError("FFmpeg gagal memproses file:\n" + r.stderr[-400:])
    return dst
