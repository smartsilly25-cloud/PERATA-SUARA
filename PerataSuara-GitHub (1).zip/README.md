# Mixing Suara - Perata Volume

Aplikasi Windows untuk meratakan volume suara (dubbing) agar konsisten, tidak keras-pelan, siap untuk video YouTube.

## Cara pakai
1. Jalankan `PerataSuara.exe`.
2. Klik **Tambah File** (bisa banyak sekaligus) atau **Tambah Folder**.
3. Pilih kekuatan perataan, target volume (default -16 LUFS), dan format hasil.
4. Klik **MULAI RATAKAN SUARA**.
5. Hasil ada di folder **Hasil** di lokasi yang sama dengan aplikasi (nama file `xxx_rata.wav`).

## Build otomatis di GitHub
Push ke branch `main`, lalu buka tab **Actions** dan unduh artifact `PerataSuara-Windows`.
Untuk membuat Release, push tag, misalnya `v1.0.0`.

## Jalankan dari kode
```
pip install -r requirements.txt
python app.py
```
